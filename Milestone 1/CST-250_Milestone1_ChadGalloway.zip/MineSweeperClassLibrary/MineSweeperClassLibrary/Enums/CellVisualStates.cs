﻿/*
 * Chad Galloway
 * CST - 250 Programming in C# II
 * 10/26/2025
 * Mine Sweeper Class Library
 * Milestone 1
 * References:
 */

namespace MineSweeperClassLibrary.Enums
{
    public enum CellVisualStates
    {
        Hidden,
        Flagged,
        Numbered,
        Bomb,
        Empty
    }
}
